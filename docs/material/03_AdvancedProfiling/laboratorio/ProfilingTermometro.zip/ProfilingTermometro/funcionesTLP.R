ClassPanelGraph <- function(var, data, cluster_hier) {
  # Función que permite la creación del Class Panel Graph con todos los gráficos correspondiente el tipo de variable
  if (is.numeric(data[,var])){
    plot <- ggplot(data = data, aes(x = data[, var])) +
      geom_histogram(fill = "gray", color = "black") +
      facet_grid(get(cluster_hier) ~ .) + ylab("") + xlab(var)
  } else {
    plot <- ggplot(data = data, aes(x = data[, var])) +
      geom_bar(fill = "gray", color = "black") +
      facet_grid(get(cluster_hier) ~ .) + ylab( "") + xlab(var) + 
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
  }
  return(plot)
}

assign_color_numeric <- function(value, min, tall1, tall2, max, type) {
  if (type == "groc") {
    return("yellow")
  } else if (type == "vermell_tall1_verd_tall2") {
    if (value < tall1) {
      return("red")
    } else if (value >= tall1 & value < tall2) {
      return("yellow")
    } else {
      return("green")
    }
  } else if (type == "verd_tall1_vermell_tall2") {
    if (value < tall1) {
      return("green")
    } else if (value >= tall1 & value < tall2) {
      return("yellow")
    } else {
      return("red")
    }
  }
}

get_mode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

cv <- function(x, na.rm = TRUE) {
  sd(x, na.rm = na.rm) / mean(x, na.rm = na.rm)
}
