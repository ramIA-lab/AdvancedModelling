# ==============================================================================
# [IDEAI] -     AdvancedProfiling.R
# 
# Author(s):    Dante Conti and Sergi Ramírez, IDEAI  (c)
# Date:         23th March 2025
# Description: 
#             Permite generar el profiling a partir del CPG, TLP y aTLP de los
#             paper de D.Conti y K.Gibert
#
# Papers:
#           - https://upcommons.upc.edu/bitstream/handle/2117/386510/8color-basedModelAIC611AuthorCopy.pdf?sequence=1&isAllowed=y
# ==============================================================================
# Cargamos las librerias necesarias 
library(dplyr)
library(cluster)
library(ggplot2)
library(purrr)
library(dendextend)
library(ggpubr)
library(tidyr)

# Cargamos la base de datos ====================================================
path <- "C:/Users/sergi/OneDrive/Escritorio/grupoW/"
url <- "https://raw.githubusercontent.com/ramIA-lab/MLforEducation/refs/heads/main/material/clustering/shopping_behavior_updated.csv"
datos <- read.csv(url)

# Preprocessing la base de datos ===============================================
tipos <- sapply(datos[, -1], class)
varNum <- names(tipos)[which(tipos %in% c("integer", "numeric"))]
varCat <- names(tipos)[which(tipos %in% c("factor", "character"))]

for(vC in varCat){datos[, vC] <- as.factor(datos[, vC])}

# Clustering ===================================================================
distances <- daisy(datos[, c(varNum, varCat)], metric = "gower")
hclust_model <- hclust(distances, method = "ward.D2")
datos$cluster <- cutree(hclust_model, k = 3)

# CPG ==========================================================================
source(paste0(path, "funcionesTLP.R"))
plots <- lapply(c(varNum, varCat), ClassPanelGraph, data = datos, 
                cluster_hier = "cluster")
CPG <- ggarrange(plotlist = plots, ncol = 5, nrow = 4)
plot(CPG)

# TERMOMETRO ===================================================================
### NUM
#### Definimos en que tipo de corte van las variables
vermell2verd <- c("Review.Rating", "Previous.Purchases")
verd2vermell <- setdiff(varNum, vermell2verd)

#### Calculamos para cada cluster i cada variable la media 
df_clustered <- datos %>% group_by(cluster) %>%
  summarise(across(where(is.numeric), mean, na.rm = TRUE)) %>% data.frame()

#### Pivotamos la tabla para tener por fila y variable el valor de la media 
datos_modelo <- df_clustered %>% 
                pivot_longer(!cluster, names_to = "variable", values_to = "sum") %>% 
                data.frame()

#### Asignamos la dirección del color si es verde - amarillo - rojo o al contrario
quien <- which(datos_modelo$variable %in% verd2vermell)
datos_modelo[quien, "direccion"] <- 1
datos_modelo[which(is.na(datos_modelo$direccion)), "direccion"] <- -1

# Asignamos el color correspondiente
listaDatos <- list()

for (var in varNum) {
  # Calculamos para la variable numerica sus cortes
  min_val <- min(datos[[var]], na.rm = TRUE)
  max_val <- max(datos[[var]], na.rm = TRUE)
  tall1_val <- quantile(datos[[var]], 0.33, na.rm = TRUE)
  tall2_val <- quantile(datos[[var]], 0.66, na.rm = TRUE)
  
  # Nos quedamos con la tabla única de valores 
  subtabla <- datos_modelo[which(datos_modelo$variable == var), ]
  
  # Clasificar en categorías 1, 2 o 3
  subtabla$grupo <- cut(subtabla$sum, 
                        breaks = c(min_val, tall1_val, tall2_val, max_val), 
                        labels = c(1, 2, 3), 
                        include.lowest = TRUE)
  
  # Asignar colores según la dirección
  subtabla$color <- ifelse(subtabla$direccion == -1, 
                     ifelse(subtabla$grupo == "1", "red",
                            ifelse(subtabla$grupo == "2", "yellow", "green")),
                     ifelse(subtabla$grupo == "1", "green",
                            ifelse(subtabla$grupo == "2", "yellow", "red"))) 
  
  # Eliminamos las variables que no nos interesan
  subtabla[, c("sum", "direccion", "grupo")] <- NULL
  listaDatos[[var]] <- subtabla
}

varNumColor <- dplyr::bind_rows(listaDatos)

### CAT ========================================================================
# Calculamos las modalidades para cada variable así poder generar un excel donde
# incorporar los colores
modalidades <- c(); variables <- c()
for (vC in varCat) {
  mod <- unique(as.character(datos[, vC])); modalidades <- c(modalidades, mod)
  variables <- c(variables, rep(vC, length(mod)))
}

dfCate <- data.frame(variables, modalidades)

# Guardamos la base de datos en un xlsx para completar  alli el color de los datos poneindo
# yellow, green, red o lilac
library(xlsx)

xlsx::write.xlsx(dfCate, file = paste0(path, "variables_categoricas.xlsx"),
  sheetName = "categorias", col.names = TRUE, row.names = FALSE)

### Aquí vamos a leer los datos de las categorias escritas en el excel 
df <- xlsx::read.xlsx(file = paste0(path, "variables_categoricas.xlsx"), 
                                     sheetName = "categorias")

# Convertir el dataframe en lista anidada
color_mapping_cat <- split(df, df$variables)  # Divide por variable
color_mapping_cat <- lapply(color_mapping_cat, function(x) {
  setNames(as.list(x$color), x$modalidades)  # Crea un subnivel por modalidad
})

df$id <- paste0(df$variables, "_", df$modalidades)


# Pivotear las variables categóricas para calcular la moda de cada una por cluster
df_moda <- datos %>%
  select(cluster, all_of(varCat)) %>%
  pivot_longer(cols = -cluster, names_to = "variable", values_to = "valor") %>%
  group_by(cluster, variable) %>%
  summarise(moda = get_mode(valor), .groups = "drop") %>% data.frame()

df_moda$id <- paste0(df_moda$variable, "_", df_moda$moda)

m <- match(df_moda$id, df$id)
df_moda$color <- df[m, "color"]
varCatColor <- df_moda %>% select(-moda, -id) %>% data.frame()

# ------------------------------------------------------------------------------
# Juntamos las bases de datos en una misma 
dfColor <- rbind(varNumColor, varCatColor)

## TLP =========================================================================
### Pintamos el TLP Completo 
ggplot(dfColor, aes(x = variable, y = factor(cluster), fill = color)) +
  geom_tile(color = "black", size = 0.5) +
  scale_fill_manual(values = c("red" = "red", "yellow" = "yellow", "green" = "green")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(title = "Traffic Light Panel (TLP)", x = "Variables", y = "Clusters")

ggsave(filename = paste0(path, "TLPCompleto.png"), width = 6, height = 4, bg = "white")

### Ahora realizamos el TLP eliminando aquellas columnas del df que no sean discri
### minatorias
dfColorRed <- dfColor
for (var in unique(dfColorRed$variable)) {
  # Nos quedamos con el subset de esas variables
  subset <- dfColorRed[which(dfColorRed$variable == var), ]
  
  # Revisamos si todos los colores son el mismo, en caso de serlo eliminamos esa variable
  # de la base de datos
  if (length(unique(subset$color)) == 1) {
    dfColorRed <- dfColorRed %>% 
                filter(variable != var)
  }
}

ggplot(dfColorRed, aes(x = variable, y = factor(cluster), fill = color)) +
  geom_tile(color = "black", size = 0.5) +
  scale_fill_manual(values = c("red" = "red", "yellow" = "yellow", "green" = "green")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(title = "Traffic Light Panel (TLP)", x = "Variables", y = "Clusters")

ggsave(filename = paste0(path, "TLP_VariablesDiscriminantes.png"), width = 6, height = 4, bg = "white")

# aTLP =========================================================================
# Para hacer el aTLP, es necesario modificar el color respecto las variables numéricas
# y calcular para cada una de ellas el CV y modificarlo 

### STEP1: Calculamos el CV para las variables numéricas 
dfCV <- datos %>%
  group_by(cluster) %>%
  summarise(across(where(is.numeric), cv, na.rm = TRUE)) %>%
  pivot_longer(!cluster, names_to = "variable", values_to = "cv") %>% 
  data.frame()
  

### STEP2: Añadimos el CV a las variables numéricas 
m <- match(paste0(dfColor$cluster, dfColor$variable), paste0(dfCV$cluster, dfCV$variable))
dfColor[, "cv"] <- dfCV[m, "cv"]

### STEP3: Asignamos RGB a los datos 
dfColor <- dfColor %>%
  mutate(R = NA, G = NA, B = NA) %>%
  mutate( 
    R = ifelse(color == "red", 255, R),
    G = ifelse(color == "red", 0, G),
    B = ifelse(color == "red", 0, B)
  ) %>%
  mutate( 
    R = ifelse(color == "green", 0, R),
    G = ifelse(color == "green", 255, G),
    B = ifelse(color == "green", 0, B)
  ) %>% mutate( 
    R = ifelse(color == "yellow", 255, R),
    G = ifelse(color == "yellow", 255, G),
    B = ifelse(color == "yellow", 0, B)
  )

# Ahora vamos a aplicar la modificación del coeficiente de variación según el color
# correspondiente 
sx <- 80 + 125*(1-dfColor$cv) + 50*(1-dfColor$cv)^2
sxa <- 180 + 180*(1-dfColor$cv) - 143*((1-dfColor$cv)^2) + 38*((1-dfColor$cv)^3)

dfColor[which(dfColor$color == "red"), "R"] <- sx[which(dfColor$color == "red")]
dfColor[which(dfColor$color == "green"), "G"] <- sx[which(dfColor$color == "green")]
dfColor[which(dfColor$color == "yellow"), "G"] <- sx[which(dfColor$color == "yellow")]
dfColor[which(dfColor$color == "yellow"), "R"] <- sxa[which(dfColor$color == "yellow")]

# Donde haya NA, se ha de volver insertar el 255
dfColor[which(is.na(dfColor$R)), "R"] <- 255
dfColor[which(is.na(dfColor$G)), "G"] <- 255

## Convertimos a valor HEX para pintar 
dfColor[, "color"] <- rgb(dfColor$R, dfColor$G, dfColor$B, maxColorValue = 255)
dfColor[, c("cv", "R", "G", "B")] <- NULL

### Graficamos el aTLP
ggplot(dfColor, aes(x = variable, y = factor(cluster), fill = color)) +
  geom_tile(color = "black", size = 0.5) +
  scale_fill_identity() +  # Usa los colores tal como están en el dataframe
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(title = "Annotated Traffic Light Panel (aTLP)", x = "Variables", y = "Clusters")

ggsave(filename = paste0(path, "aTLPCompleto.png"), width = 6, height = 4, bg = "white")

### Graficamos el aTLP sólo de las variables importantes 
dfColorRed <- dfColor
for (var in unique(dfColorRed$variable)) {
  # Nos quedamos con el subset de esas variables
  subset <- dfColorRed[which(dfColorRed$variable == var), ]
  
  # Revisamos si todos los colores son el mismo, en caso de serlo eliminamos esa variable
  # de la base de datos
  if (length(unique(subset$color)) == 1) {
    dfColorRed <- dfColorRed %>% 
      filter(variable != var)
  }
}

ggplot(dfColorRed, aes(x = variable, y = factor(cluster), fill = color)) +
  geom_tile(color = "black", size = 0.5) +
  scale_fill_identity() +  # Usa los colores tal como están en el dataframe
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(title = "Annotated Traffic Light Panel (aTLP)", x = "Variables", y = "Clusters")

ggsave(filename = paste0(path, "aTLP_VariablesDiscriminantes.png"), width = 6, height = 4, bg = "white")

